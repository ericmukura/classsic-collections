"use client"

import * as React from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

const banners = [
  {
    id: 1,
    title: "Men's Fashion Collection",
    description: "Elevate your style with our premium casual wear",
    image: "/images/products/mens-outfit.jpeg",
    cta: "Shop Men's",
    href: "/category/mens-fashion",
    color: "bg-emerald-600",
  },
  {
    id: 2,
    title: "Summer Vibes",
    description: "Discover our new palm print collection for the season",
    image: "/images/products/palm-set.jpeg",
    cta: "Explore",
    href: "/category/summer-collection",
    color: "bg-blue-600",
  },
  {
    id: 3,
    title: "Exclusive Sneakers",
    description: "Limited edition Jordan collection now available",
    image: "/images/products/jordan-smoke.jpeg",
    cta: "View Collection",
    href: "/category/shoes",
    color: "bg-red-600",
  },
]

export function HeroBanner() {
  const [currentBanner, setCurrentBanner] = React.useState(0)

  const nextBanner = () => {
    setCurrentBanner((prev) => (prev + 1) % banners.length)
  }

  const prevBanner = () => {
    setCurrentBanner((prev) => (prev - 1 + banners.length) % banners.length)
  }

  React.useEffect(() => {
    const interval = setInterval(() => {
      nextBanner()
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative overflow-hidden">
      <div className="relative h-[300px] md:h-[400px] lg:h-[500px] w-full">
        {banners.map((banner, index) => (
          <div
            key={banner.id}
            className={cn(
              "absolute inset-0 transition-opacity duration-500",
              index === currentBanner ? "opacity-100" : "opacity-0 pointer-events-none",
            )}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent z-10" />
            <Image
              src={banner.image || "/placeholder.svg"}
              alt={banner.title}
              fill
              className="object-cover"
              priority={index === 0}
              quality={90}
              sizes="100vw"
            />
            <div className="absolute inset-0 z-20 flex flex-col justify-center px-6 md:px-12 lg:px-24">
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">{banner.title}</h1>
              <p className="text-white/90 text-lg md:text-xl max-w-md mb-6">{banner.description}</p>
              <div>
                <Button asChild size="lg" className={cn("text-white", banner.color)}>
                  <Link href={banner.href}>{banner.cta}</Link>
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <Button
        variant="ghost"
        size="icon"
        className="absolute left-2 top-1/2 z-30 -translate-y-1/2 bg-black/20 text-white hover:bg-black/40"
        onClick={prevBanner}
      >
        <ChevronLeft className="h-6 w-6" />
        <span className="sr-only">Previous banner</span>
      </Button>

      <Button
        variant="ghost"
        size="icon"
        className="absolute right-2 top-1/2 z-30 -translate-y-1/2 bg-black/20 text-white hover:bg-black/40"
        onClick={nextBanner}
      >
        <ChevronRight className="h-6 w-6" />
        <span className="sr-only">Next banner</span>
      </Button>

      <div className="absolute bottom-4 left-1/2 z-30 flex -translate-x-1/2 gap-2">
        {banners.map((_, index) => (
          <button
            key={index}
            className={cn(
              "h-2 w-2 rounded-full transition-colors",
              index === currentBanner ? "bg-white" : "bg-white/50",
            )}
            onClick={() => setCurrentBanner(index)}
          >
            <span className="sr-only">Banner {index + 1}</span>
          </button>
        ))}
      </div>
    </div>
  )
}

