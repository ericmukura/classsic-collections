"use client"

import { useState } from "react"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { Loader2, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { initiatePayment } from "@/app/actions/payment-actions"
import { useToast } from "@/components/ui/use-toast"

const formSchema = z.object({
  phoneNumber: z
    .string()
    .min(10, { message: "Phone number must be at least 10 digits" })
    .max(12, { message: "Phone number must not exceed 12 digits" })
    .regex(/^(07|01|2547|2541)\d{8}$/, {
      message: "Please enter a valid Kenyan phone number (e.g., 07XXXXXXXX or 254XXXXXXXX)",
    }),
})

interface MpesaPaymentProps {
  amount: number
  orderId: string
  onSuccess: () => void
}

export function MpesaPayment({ amount, orderId, onSuccess }: MpesaPaymentProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [paymentStatus, setPaymentStatus] = useState<"idle" | "processing" | "success" | "error">("idle")
  const { toast } = useToast()

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      phoneNumber: "",
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true)
    setPaymentStatus("processing")

    try {
      // Format phone number to ensure it starts with 254
      let formattedPhone = values.phoneNumber
      if (formattedPhone.startsWith("0")) {
        formattedPhone = "254" + formattedPhone.substring(1)
      }

      // In a real app, this would call the actual M-Pesa API
      const result = await initiatePayment({
        phoneNumber: formattedPhone,
        amount,
        orderId,
      })

      // Simulate payment processing delay
      setTimeout(() => {
        setPaymentStatus("success")
        setIsSubmitting(false)
        toast({
          title: "Payment initiated successfully",
          description: "Please check your phone for the M-Pesa prompt and enter your PIN to complete payment.",
        })

        // Simulate successful payment after 5 seconds
        setTimeout(() => {
          onSuccess()
        }, 5000)
      }, 3000)
    } catch (error) {
      setPaymentStatus("error")
      setIsSubmitting(false)
      toast({
        title: "Payment failed",
        description: "There was an error processing your payment. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <img src="/images/mpesa-logo.png" alt="M-Pesa" className="h-8" />
          M-Pesa Payment
        </CardTitle>
        <CardDescription>
          Pay securely using M-Pesa. You will receive a prompt on your phone to complete the payment.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {paymentStatus === "success" ? (
          <div className="flex flex-col items-center justify-center py-6 text-center">
            <CheckCircle2 className="h-16 w-16 text-green-500 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Payment Initiated Successfully</h3>
            <p className="text-muted-foreground mb-4">
              Please check your phone for the M-Pesa prompt and enter your PIN to complete payment.
            </p>
            <div className="bg-muted p-4 rounded-md w-full max-w-xs">
              <p className="font-medium">Amount: Ksh {amount.toLocaleString()}</p>
              <p className="text-sm text-muted-foreground">Order ID: {orderId}</p>
            </div>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="phoneNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number</FormLabel>
                    <FormControl>
                      <Input placeholder="07XXXXXXXX or 254XXXXXXXX" {...field} />
                    </FormControl>
                    <FormDescription>Enter the phone number registered with M-Pesa</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="bg-muted p-4 rounded-md">
                <p className="font-medium">Amount: Ksh {amount.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Order ID: {orderId}</p>
              </div>
            </form>
          </Form>
        )}
      </CardContent>
      <CardFooter>
        {paymentStatus !== "success" && (
          <Button type="submit" className="w-full" disabled={isSubmitting} onClick={form.handleSubmit(onSubmit)}>
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Processing...
              </>
            ) : (
              "Pay with M-Pesa"
            )}
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}

