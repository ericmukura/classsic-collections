import Link from "next/link"
import Image from "next/image"

const categories = [
  {
    name: "Men's Fashion",
    image: "/images/products/mens-outfit.jpeg",
    href: "/category/mens-fashion",
  },
  {
    name: "Women's Fashion",
    image: "/images/products/brooklyn-outfit.jpeg",
    href: "/category/womens-fashion",
  },
  {
    name: "Kids' Fashion",
    image: "/images/products/kids-dress.jpeg",
    href: "/category/kids-fashion",
  },
  {
    name: "Shoes",
    image: "/images/products/jordan-red.jpeg",
    href: "/category/shoes",
  },
  {
    name: "Watches",
    image: "/images/products/smartwatch.jpeg",
    href: "/category/watches",
  },
  {
    name: "Electronics",
    image: "/images/products/headphones-green.jpeg",
    href: "/category/electronics",
  },
]

export function CategoryGrid() {
  return (
    <section className="py-12 bg-muted">
      <div className="container">
        <h2 className="text-2xl font-bold mb-8 text-center">Shop by Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((category) => (
            <Link key={category.name} href={category.href} className="group relative overflow-hidden rounded-lg">
              <div className="aspect-square relative">
                <Image
                  src={category.image || "/placeholder.svg"}
                  alt={category.name}
                  fill
                  sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 16vw"
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                  priority={category.name === "Men's Fashion" || category.name === "Women's Fashion"}
                  quality={90}
                />
                <div className="absolute inset-0 bg-black/30 group-hover:bg-black/40 transition-colors" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <h3 className="text-white font-medium text-center px-2">{category.name}</h3>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}

