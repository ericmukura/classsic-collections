import Link from "next/link"
import { ProductCard } from "@/components/product-card"
import { Button } from "@/components/ui/button"
import { ChevronRight } from "lucide-react"

// Expanded product database with more products for each category
const allProducts = [
  // Men's Fashion
  {
    id: "1",
    name: "Men's Casual Outfit",
    price: 4999,
    originalPrice: 6499,
    image: "/images/products/mens-outfit.jpeg",
    category: "Men's Fashion",
    isNew: true,
    slug: "mens-casual-outfit",
  },
  {
    id: "2",
    name: "Palm Print Set",
    price: 3299,
    originalPrice: 4599,
    image: "/images/products/palm-set.jpeg",
    category: "Men's Fashion",
    isSale: true,
    slug: "palm-print-set",
  },
  {
    id: "11",
    name: "Men's Formal Shirt",
    price: 2499,
    image: "/images/products/mens-shirt.jpg",
    category: "Men's Fashion",
    slug: "mens-formal-shirt",
  },

  // Women's Fashion
  {
    id: "6",
    name: "Brooklyn Sweatshirt Set",
    price: 3999,
    image: "/images/products/brooklyn-outfit.jpeg",
    category: "Women's Fashion",
    slug: "brooklyn-sweatshirt-set",
  },
  {
    id: "12",
    name: "Women's Summer Dress",
    price: 3599,
    image: "/images/products/womens-dress.jpg",
    category: "Women's Fashion",
    isNew: true,
    slug: "womens-summer-dress",
  },

  // Kids' Fashion
  {
    id: "5",
    name: "Kids Pink Dress",
    price: 2899,
    image: "/images/products/kids-dress.jpeg",
    category: "Kids' Fashion",
    slug: "kids-pink-dress",
  },
  {
    id: "13",
    name: "Kids Sneakers",
    price: 1999,
    image: "/images/products/kids-sneakers.jpg",
    category: "Kids' Fashion",
    slug: "kids-sneakers",
  },

  // Electronics
  {
    id: "3",
    name: "Smart Watch",
    price: 5999,
    image: "/images/products/smartwatch.jpeg",
    category: "Electronics",
    isNew: true,
    slug: "smart-watch",
  },
  {
    id: "4",
    name: "Wireless Headphones",
    price: 7499,
    originalPrice: 9999,
    image: "/images/products/headphones-green.jpeg",
    category: "Electronics",
    isSale: true,
    slug: "wireless-headphones",
  },

  // Home Furniture
  {
    id: "7",
    name: "Modern Coffee Table",
    price: 8499,
    originalPrice: 10999,
    image: "/images/products/coffee-table-modern.jpeg",
    category: "Home Furniture",
    isSale: true,
    slug: "modern-coffee-table",
  },
  {
    id: "14",
    name: "Classic Coffee Table",
    price: 7499,
    image: "/images/products/coffee-table.jpg",
    category: "Home Furniture",
    slug: "classic-coffee-table",
  },

  // Shoes
  {
    id: "8",
    name: "Air Jordan 1 Iridescent",
    price: 12599,
    image: "/images/products/jordan-iridescent.jpeg",
    category: "Shoes",
    isNew: true,
    slug: "air-jordan-1-iridescent",
  },
  {
    id: "9",
    name: "Air Jordan Chicago",
    price: 14999,
    image: "/images/products/jordan-red.jpeg",
    category: "Shoes",
    isNew: true,
    slug: "air-jordan-chicago",
  },
  {
    id: "10",
    name: "Air Jordan Smoke",
    price: 15999,
    originalPrice: 17999,
    image: "/images/products/jordan-smoke.jpeg",
    category: "Shoes",
    isNew: true,
    slug: "air-jordan-smoke",
  },
  {
    id: "15",
    name: "Running Shoes",
    price: 6999,
    image: "/images/products/running-shoes.jpg",
    category: "Shoes",
    slug: "running-shoes",
  },

  // Watches
  {
    id: "16",
    name: "Leather Watch",
    price: 8999,
    image: "/images/products/watch.jpg",
    category: "Watches",
    slug: "leather-watch",
  },

  // Jewelry
  {
    id: "17",
    name: "Gold Pendant",
    price: 12999,
    image: "/images/products/pendant.jpg",
    category: "Jewelry",
    slug: "gold-pendant",
  },
]

// Featured products selection
const featuredProducts = [
  allProducts.find((p) => p.id === "1")!,
  allProducts.find((p) => p.id === "2")!,
  allProducts.find((p) => p.id === "3")!,
  allProducts.find((p) => p.id === "4")!,
  allProducts.find((p) => p.id === "5")!,
  allProducts.find((p) => p.id === "6")!,
  allProducts.find((p) => p.id === "7")!,
  allProducts.find((p) => p.id === "8")!,
]

// New arrivals selection
const newArrivals = [
  allProducts.find((p) => p.id === "9")!,
  allProducts.find((p) => p.id === "10")!,
  allProducts.find((p) => p.id === "3")!,
  allProducts.find((p) => p.id === "1")!,
]

interface FeaturedProductsProps {
  title: string
  viewAllLink: string
  products?: typeof featuredProducts
  limit?: number
}

export function FeaturedProducts({
  title,
  viewAllLink,
  products = featuredProducts,
  limit = 8,
}: FeaturedProductsProps) {
  // Use newArrivals if the title includes "New Arrivals"
  const sourceProducts = title.includes("New Arrivals") ? newArrivals : products
  const displayProducts = sourceProducts.slice(0, limit)

  return (
    <section className="py-12">
      <div className="container">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold">{title}</h2>
          <Button variant="ghost" asChild>
            <Link href={viewAllLink} className="flex items-center gap-1">
              View All <ChevronRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {displayProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  )
}

