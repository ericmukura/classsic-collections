"use client"

import * as React from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ShoppingCart, User, Search, Menu, Heart, Sun, Moon } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useTheme } from "next-themes"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { MobileNav } from "@/components/mobile-nav"

const categories = [
  { name: "Men's Fashion", href: "/category/mens-fashion" },
  { name: "Women's Fashion", href: "/category/womens-fashion" },
  { name: "Kids' Fashion", href: "/category/kids-fashion" },
  { name: "Shoes", href: "/category/shoes" },
  { name: "Watches", href: "/category/watches" },
  { name: "Jewelry", href: "/category/jewelry" },
  { name: "Electronics", href: "/category/electronics" },
  { name: "Home Furniture", href: "/category/home-furniture" },
]

export function MainNav() {
  const pathname = usePathname()
  const { setTheme, theme } = useTheme()
  const [showSearch, setShowSearch] = React.useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background">
      <div className="container flex h-16 items-center">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="pr-0">
            <MobileNav />
          </SheetContent>
        </Sheet>

        <Link href="/" className="mr-6 flex items-center space-x-2">
          <span className="font-bold">Classic Collection</span>
        </Link>

        <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
          <Link
            href="/"
            className={cn(
              "transition-colors hover:text-foreground/80",
              pathname === "/" ? "text-foreground" : "text-foreground/60",
            )}
          >
            Home
          </Link>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="link" className="p-0">
                Shop
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              {categories.map((category) => (
                <DropdownMenuItem key={category.name} asChild>
                  <Link href={category.href}>{category.name}</Link>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <Link
            href="/contact"
            className={cn(
              "transition-colors hover:text-foreground/80",
              pathname === "/contact" ? "text-foreground" : "text-foreground/60",
            )}
          >
            Contact
          </Link>
        </nav>

        <div className="flex-1" />

        {showSearch ? (
          <div className="relative w-full max-w-sm mr-4">
            <Input placeholder="Search products..." className="pr-8" autoFocus onBlur={() => setShowSearch(false)} />
            <Search className="absolute right-2 top-2.5 h-4 w-4 text-muted-foreground" />
          </div>
        ) : (
          <Button variant="ghost" size="icon" className="mr-2" onClick={() => setShowSearch(true)}>
            <Search className="h-5 w-5" />
            <span className="sr-only">Search</span>
          </Button>
        )}

        <Button variant="ghost" size="icon" className="mr-2">
          <Heart className="h-5 w-5" />
          <span className="sr-only">Wishlist</span>
        </Button>

        <Button variant="ghost" size="icon" className="mr-2" asChild>
          <Link href="/cart">
            <ShoppingCart className="h-5 w-5" />
            <span className="sr-only">Cart</span>
          </Link>
        </Button>

        <Button variant="ghost" size="icon" className="mr-2" asChild>
          <Link href="/account">
            <User className="h-5 w-5" />
            <span className="sr-only">Account</span>
          </Link>
        </Button>

        <Button variant="ghost" size="icon" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
          <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
          <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
          <span className="sr-only">Toggle theme</span>
        </Button>
      </div>
    </header>
  )
}

