"use client"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const categories = [
  { name: "Men's Fashion", href: "/category/mens-fashion" },
  { name: "Women's Fashion", href: "/category/womens-fashion" },
  { name: "Kids' Fashion", href: "/category/kids-fashion" },
  { name: "Shoes", href: "/category/shoes" },
  { name: "Watches", href: "/category/watches" },
  { name: "Jewelry", href: "/category/jewelry" },
  { name: "Electronics", href: "/category/electronics" },
  { name: "Home Furniture", href: "/category/home-furniture" },
]

export function MobileNav() {
  const pathname = usePathname()

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center border-b px-4 py-4">
        <Link href="/" className="flex items-center gap-2">
          <span className="font-bold">Classic Collection</span>
        </Link>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-4 pb-16">
          <div className="flex flex-col space-y-3">
            <Link
              href="/"
              className={cn(
                "flex items-center text-sm font-medium",
                pathname === "/" ? "text-foreground" : "text-foreground/60",
              )}
            >
              Home
            </Link>
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="categories">
                <AccordionTrigger className="text-sm font-medium">Shop</AccordionTrigger>
                <AccordionContent>
                  <div className="flex flex-col space-y-2 pl-4">
                    {categories.map((category) => (
                      <Link
                        key={category.name}
                        href={category.href}
                        className={cn("text-sm", pathname === category.href ? "text-foreground" : "text-foreground/60")}
                      >
                        {category.name}
                      </Link>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
            <Link
              href="/contact"
              className={cn(
                "flex items-center text-sm font-medium",
                pathname === "/contact" ? "text-foreground" : "text-foreground/60",
              )}
            >
              Contact
            </Link>
          </div>
          <div className="mt-6 pt-6 border-t">
            <div className="flex flex-col space-y-3">
              <Link href="/account" className="text-sm font-medium text-foreground/60">
                Account
              </Link>
              <Link href="/wishlist" className="text-sm font-medium text-foreground/60">
                Wishlist
              </Link>
              <Link href="/cart" className="text-sm font-medium text-foreground/60">
                Cart
              </Link>
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  )
}

