import Link from "next/link"
import Image from "next/image"
import { Heart, ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface ProductCardProps {
  product: {
    id: string
    name: string
    price: number
    originalPrice?: number
    image: string
    category: string
    isNew?: boolean
    isSale?: boolean
    rating?: number
    slug: string
  }
  className?: string
}

export function ProductCard({ product, className }: ProductCardProps) {
  return (
    <Card className={cn("overflow-hidden group", className)}>
      <div className="relative aspect-square overflow-hidden">
        <Link href={`/product/${product.slug}`}>
          <Image
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            fill
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
            className="object-cover transition-transform duration-300 group-hover:scale-105"
            quality={85}
          />
        </Link>
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.isNew && <Badge className="bg-blue-500 hover:bg-blue-600">New</Badge>}
          {product.isSale && <Badge variant="destructive">Sale</Badge>}
        </div>
        <div className="absolute top-2 right-2">
          <Button variant="ghost" size="icon" className="rounded-full bg-white/80 text-foreground hover:bg-white">
            <Heart className="h-4 w-4" />
            <span className="sr-only">Add to wishlist</span>
          </Button>
        </div>
      </div>
      <CardContent className="p-4">
        <div className="text-sm text-muted-foreground mb-1">{product.category}</div>
        <Link href={`/product/${product.slug}`} className="hover:underline">
          <h3 className="font-medium line-clamp-2">{product.name}</h3>
        </Link>
        <div className="flex items-center gap-2 mt-2">
          <div className="font-semibold">Ksh {product.price.toLocaleString()}</div>
          {product.originalPrice && (
            <div className="text-sm text-muted-foreground line-through">
              Ksh {product.originalPrice.toLocaleString()}
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button className="w-full gap-2">
          <ShoppingCart className="h-4 w-4" />
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  )
}

