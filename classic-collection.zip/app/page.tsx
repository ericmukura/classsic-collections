import { HeroBanner } from "@/components/hero-banner"
import { FeaturedProducts } from "@/components/featured-products"
import { CategoryGrid } from "@/components/category-grid"
import { Newsletter } from "@/components/newsletter"
import { Footer } from "@/components/footer"
import { MainNav } from "@/components/main-nav"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <MainNav />
      <main className="flex-1">
        <HeroBanner />
        <FeaturedProducts title="Featured Products" viewAllLink="/products" />
        <CategoryGrid />
        <FeaturedProducts title="New Arrivals" viewAllLink="/category/new-arrivals" limit={4} />
        <Newsletter />
      </main>
      <Footer />
    </div>
  )
}

