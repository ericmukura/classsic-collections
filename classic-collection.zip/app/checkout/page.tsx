"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ChevronRight, CreditCard, Truck, ShoppingBag } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { MainNav } from "@/components/main-nav"
import { Footer } from "@/components/footer"
import { MpesaPayment } from "@/components/checkout/mpesa-payment"
import { useToast } from "@/components/ui/use-toast"

// Mock cart items
const cartItems = [
  {
    id: "1",
    name: "Men's Casual Outfit",
    price: 4999,
    quantity: 1,
    image: "/images/products/mens-outfit.jpeg",
  },
  {
    id: "4",
    name: "Wireless Headphones",
    price: 7499,
    quantity: 1,
    image: "/images/products/headphones-green.jpeg",
  },
]

export default function CheckoutPage() {
  const [paymentMethod, setPaymentMethod] = useState("mpesa")
  const [orderStatus, setOrderStatus] = useState<"pending" | "processing" | "completed">("pending")
  const router = useRouter()
  const { toast } = useToast()

  // Calculate order summary
  const subtotal = cartItems.reduce((total, item) => total + item.price * item.quantity, 0)
  const shipping = 350
  const total = subtotal + shipping

  // Generate a random order ID
  const orderId = `KE-${Math.floor(Math.random() * 10000)}`

  const handlePaymentSuccess = () => {
    setOrderStatus("completed")
    toast({
      title: "Payment successful!",
      description: "Your order has been placed successfully.",
    })

    // Redirect to order confirmation page after a delay
    setTimeout(() => {
      router.push(`/order-confirmation?orderId=${orderId}`)
    }, 2000)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <MainNav />
      <main className="flex-1 py-10">
        <div className="container">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Checkout</h1>
            <div className="flex items-center text-sm text-muted-foreground">
              <span>Cart</span>
              <ChevronRight className="h-4 w-4 mx-1" />
              <span className={orderStatus === "pending" ? "font-medium text-foreground" : ""}>Checkout</span>
              <ChevronRight className="h-4 w-4 mx-1" />
              <span className={orderStatus === "completed" ? "font-medium text-foreground" : ""}>Confirmation</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              {/* Order Items */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ShoppingBag className="h-5 w-5" />
                    Order Items
                  </CardTitle>
                  <CardDescription>Review your items before checkout</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {cartItems.map((item) => (
                      <div key={item.id} className="flex items-center gap-4">
                        <div className="h-16 w-16 rounded-md overflow-hidden relative">
                          <img
                            src={item.image || "/placeholder.svg"}
                            alt={item.name}
                            className="object-cover h-full w-full"
                          />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{item.name}</h3>
                          <p className="text-sm text-muted-foreground">Quantity: {item.quantity}</p>
                        </div>
                        <div className="font-medium">Ksh {item.price.toLocaleString()}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Shipping Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Truck className="h-5 w-5" />
                    Shipping Information
                  </CardTitle>
                  <CardDescription>Enter your shipping details</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-1 block">Full Name</label>
                      <input type="text" className="w-full p-2 border rounded-md" defaultValue="John Doe" />
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-1 block">Phone Number</label>
                      <input type="text" className="w-full p-2 border rounded-md" defaultValue="0712345678" />
                    </div>
                    <div className="md:col-span-2">
                      <label className="text-sm font-medium mb-1 block">Email Address</label>
                      <input
                        type="email"
                        className="w-full p-2 border rounded-md"
                        defaultValue="john.doe@example.com"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="text-sm font-medium mb-1 block">Address</label>
                      <input type="text" className="w-full p-2 border rounded-md" defaultValue="123 Moi Avenue" />
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-1 block">City</label>
                      <input type="text" className="w-full p-2 border rounded-md" defaultValue="Nairobi" />
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-1 block">Postal Code</label>
                      <input type="text" className="w-full p-2 border rounded-md" defaultValue="00100" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Method */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="h-5 w-5" />
                    Payment Method
                  </CardTitle>
                  <CardDescription>Choose how you want to pay</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="mpesa" onValueChange={setPaymentMethod}>
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="mpesa">M-Pesa</TabsTrigger>
                      <TabsTrigger value="card">Credit Card</TabsTrigger>
                    </TabsList>
                    <TabsContent value="mpesa" className="pt-4">
                      <MpesaPayment amount={total} orderId={orderId} onSuccess={handlePaymentSuccess} />
                    </TabsContent>
                    <TabsContent value="card" className="pt-4">
                      <Card>
                        <CardHeader>
                          <CardTitle>Credit Card Payment</CardTitle>
                          <CardDescription>Pay securely using your credit or debit card</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-center py-4 text-muted-foreground">
                            Credit card payment is currently unavailable. Please use M-Pesa.
                          </p>
                        </CardContent>
                      </Card>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>

            {/* Order Summary */}
            <div>
              <Card className="sticky top-6">
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span>Ksh {subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Shipping</span>
                    <span>Ksh {shipping.toLocaleString()}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-medium text-lg">
                    <span>Total</span>
                    <span>Ksh {total.toLocaleString()}</span>
                  </div>
                  <div className="text-xs text-muted-foreground">Order ID: {orderId}</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

