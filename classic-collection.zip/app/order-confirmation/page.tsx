"use client"

import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { CheckCircle2, ArrowRight, Home, Package } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MainNav } from "@/components/main-nav"
import { Footer } from "@/components/footer"

export default function OrderConfirmationPage() {
  const searchParams = useSearchParams()
  const orderId = searchParams.get("orderId") || "KE-1234"

  // Generate a random transaction ID
  const transactionId = `MPESA${Math.floor(Math.random() * 1000000)}`

  // Generate a random delivery date (3-5 days from now)
  const deliveryDays = Math.floor(Math.random() * 3) + 3
  const deliveryDate = new Date()
  deliveryDate.setDate(deliveryDate.getDate() + deliveryDays)

  return (
    <div className="flex min-h-screen flex-col">
      <MainNav />
      <main className="flex-1 py-10">
        <div className="container max-w-3xl">
          <div className="flex flex-col items-center text-center mb-8">
            <div className="bg-green-100 p-4 rounded-full mb-4">
              <CheckCircle2 className="h-16 w-16 text-green-600" />
            </div>
            <h1 className="text-3xl font-bold mb-2">Order Confirmed!</h1>
            <p className="text-muted-foreground max-w-md">
              Thank you for your purchase. Your order has been confirmed and will be shipped soon.
            </p>
          </div>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Order Details</CardTitle>
              <CardDescription>Your order information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Order Number</h3>
                  <p className="font-medium">{orderId}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Payment Method</h3>
                  <p className="font-medium">M-Pesa</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Transaction ID</h3>
                  <p className="font-medium">{transactionId}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Order Date</h3>
                  <p className="font-medium">{new Date().toLocaleDateString()}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Estimated Delivery</h3>
                  <p className="font-medium">{deliveryDate.toLocaleDateString()}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Order Status</h3>
                  <p className="font-medium">Processing</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Delivery Information</CardTitle>
              <CardDescription>Where we're sending your items</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                <p className="font-medium">John Doe</p>
                <p>123 Moi Avenue</p>
                <p>Nairobi, 00100</p>
                <p>Kenya</p>
                <p>Phone: 0712345678</p>
              </div>
            </CardContent>
          </Card>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild variant="outline" size="lg" className="gap-2">
              <Link href="/">
                <Home className="h-4 w-4" />
                Return to Home
              </Link>
            </Button>
            <Button asChild size="lg" className="gap-2">
              <Link href="/account/orders">
                <Package className="h-4 w-4" />
                Track Order
                <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </Button>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

