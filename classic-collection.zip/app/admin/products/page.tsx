"use client"

import { useState, useEffect } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Plus, Search, MoreHorizontal, Edit, Trash2, Eye, Loader2 } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Image from "next/image"

interface Product {
  id: string
  name: string
  category: string
  price: number
  stock: number
  status: "in-stock" | "low-stock" | "out-of-stock"
  createdAt: string
  image: string
}

// Mock data function with expanded product list covering all categories
const fetchProducts = (): Promise<Product[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        // Men's Fashion
        {
          id: "PROD-001",
          name: "Men's Casual Outfit",
          category: "Men's Fashion",
          price: 4999,
          stock: 45,
          status: "in-stock",
          createdAt: "2023-01-15",
          image: "/images/products/mens-outfit.jpeg",
        },
        {
          id: "PROD-002",
          name: "Palm Print Set",
          category: "Men's Fashion",
          price: 3299,
          stock: 32,
          status: "in-stock",
          createdAt: "2023-01-20",
          image: "/images/products/palm-set.jpeg",
        },
        {
          id: "PROD-011",
          name: "Men's Formal Shirt",
          category: "Men's Fashion",
          price: 2499,
          stock: 28,
          status: "in-stock",
          createdAt: "2023-01-25",
          image: "/images/products/mens-shirt.jpg",
        },

        // Women's Fashion
        {
          id: "PROD-006",
          name: "Brooklyn Sweatshirt Set",
          category: "Women's Fashion",
          price: 3999,
          stock: 0,
          status: "out-of-stock",
          createdAt: "2023-02-20",
          image: "/images/products/brooklyn-outfit.jpeg",
        },
        {
          id: "PROD-012",
          name: "Women's Summer Dress",
          category: "Women's Fashion",
          price: 3599,
          stock: 15,
          status: "in-stock",
          createdAt: "2023-02-22",
          image: "/images/products/womens-dress.jpg",
        },

        // Kids' Fashion
        {
          id: "PROD-005",
          name: "Kids Pink Dress",
          category: "Kids' Fashion",
          price: 2899,
          stock: 23,
          status: "in-stock",
          createdAt: "2023-02-15",
          image: "/images/products/kids-dress.jpeg",
        },
        {
          id: "PROD-013",
          name: "Kids Sneakers",
          category: "Kids' Fashion",
          price: 1999,
          stock: 8,
          status: "low-stock",
          createdAt: "2023-02-18",
          image: "/images/products/kids-sneakers.jpg",
        },

        // Electronics
        {
          id: "PROD-003",
          name: "Smart Watch",
          category: "Electronics",
          price: 5999,
          stock: 18,
          status: "in-stock",
          createdAt: "2023-02-05",
          image: "/images/products/smartwatch.jpeg",
        },
        {
          id: "PROD-004",
          name: "Wireless Headphones",
          category: "Electronics",
          price: 7499,
          stock: 7,
          status: "low-stock",
          createdAt: "2023-02-10",
          image: "/images/products/headphones-green.jpeg",
        },

        // Home Furniture
        {
          id: "PROD-007",
          name: "Modern Coffee Table",
          category: "Home Furniture",
          price: 8499,
          stock: 5,
          status: "low-stock",
          createdAt: "2023-03-01",
          image: "/images/products/coffee-table-modern.jpeg",
        },
        {
          id: "PROD-014",
          name: "Classic Coffee Table",
          category: "Home Furniture",
          price: 7499,
          stock: 12,
          status: "in-stock",
          createdAt: "2023-03-03",
          image: "/images/products/coffee-table.jpg",
        },

        // Shoes
        {
          id: "PROD-008",
          name: "Air Jordan 1 Iridescent",
          category: "Shoes",
          price: 12599,
          stock: 12,
          status: "in-stock",
          createdAt: "2023-03-05",
          image: "/images/products/jordan-iridescent.jpeg",
        },
        {
          id: "PROD-009",
          name: "Air Jordan Chicago",
          category: "Shoes",
          price: 14999,
          stock: 3,
          status: "low-stock",
          createdAt: "2023-03-10",
          image: "/images/products/jordan-red.jpeg",
        },
        {
          id: "PROD-010",
          name: "Air Jordan Smoke",
          category: "Shoes",
          price: 15999,
          stock: 0,
          status: "out-of-stock",
          createdAt: "2023-03-15",
          image: "/images/products/jordan-smoke.jpeg",
        },
        {
          id: "PROD-015",
          name: "Running Shoes",
          category: "Shoes",
          price: 6999,
          stock: 20,
          status: "in-stock",
          createdAt: "2023-03-18",
          image: "/images/products/running-shoes.jpg",
        },

        // Watches
        {
          id: "PROD-016",
          name: "Leather Watch",
          category: "Watches",
          price: 8999,
          stock: 14,
          status: "in-stock",
          createdAt: "2023-03-20",
          image: "/images/products/watch.jpg",
        },

        // Jewelry
        {
          id: "PROD-017",
          name: "Gold Pendant",
          category: "Jewelry",
          price: 12999,
          stock: 6,
          status: "low-stock",
          createdAt: "2023-03-22",
          image: "/images/products/pendant.jpg",
        },
      ])
    }, 1000)
  })
}

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")

  useEffect(() => {
    const loadProducts = async () => {
      setIsLoading(true)
      try {
        const data = await fetchProducts()
        setProducts(data)
        setFilteredProducts(data)
      } catch (error) {
        console.error("Error loading products:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadProducts()
  }, [])

  useEffect(() => {
    let filtered = products

    // Apply category filter
    if (categoryFilter !== "all") {
      filtered = filtered.filter((product) => product.category === categoryFilter)
    }

    // Apply search filter
    if (searchQuery.trim() !== "") {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (product) =>
          product.name.toLowerCase().includes(query) ||
          product.category.toLowerCase().includes(query) ||
          product.id.toLowerCase().includes(query),
      )
    }

    setFilteredProducts(filtered)
  }, [searchQuery, categoryFilter, products])

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "in-stock":
        return <Badge className="bg-green-500">In Stock</Badge>
      case "low-stock":
        return <Badge className="bg-yellow-500">Low Stock</Badge>
      case "out-of-stock":
        return <Badge className="bg-red-500">Out of Stock</Badge>
      default:
        return <Badge>Unknown</Badge>
    }
  }

  // Get unique categories from products
  const categories = [...new Set(products.map((product) => product.category))]

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Products</h1>
          <p className="text-muted-foreground">Manage your product inventory and listings.</p>
        </div>
        <Button className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Add Product
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <CardTitle>Product Inventory</CardTitle>
              <CardDescription>
                {isLoading
                  ? "Loading products..."
                  : `Showing ${filteredProducts.length} of ${products.length} products`}
              </CardDescription>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search products..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-full sm:w-40">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="h-96 flex items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Stock</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Added</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProducts.map((product) => (
                  <TableRow key={product.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 relative rounded overflow-hidden">
                          <Image
                            src={product.image || "/placeholder.svg"}
                            alt={product.name}
                            fill
                            className="object-cover"
                            sizes="40px"
                          />
                        </div>
                        <div>
                          <div className="font-medium">{product.name}</div>
                          <div className="text-xs text-muted-foreground">{product.id}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{product.category}</TableCell>
                    <TableCell>Ksh {product.price.toLocaleString()}</TableCell>
                    <TableCell>{product.stock}</TableCell>
                    <TableCell>{getStatusBadge(product.status)}</TableCell>
                    <TableCell>{new Date(product.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Open menu</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="flex items-center gap-2">
                            <Eye className="h-4 w-4" /> View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem className="flex items-center gap-2">
                            <Edit className="h-4 w-4" /> Edit Product
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="flex items-center gap-2 text-red-500">
                            <Trash2 className="h-4 w-4" /> Delete Product
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

