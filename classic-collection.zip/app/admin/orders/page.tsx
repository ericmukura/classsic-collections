"use client"

import { useState, useEffect } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Search, MoreHorizontal, Eye, Loader2, FileText, Truck, XCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Order {
  id: string
  customer: string
  email: string
  items: number
  total: number
  status: "pending" | "processing" | "shipped" | "delivered" | "cancelled"
  date: string
  paymentMethod: string
}

// Mock data function
const fetchOrders = (): Promise<Order[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        {
          id: "#KE-2345",
          customer: "John Doe",
          email: "john.doe@example.com",
          items: 3,
          total: 12500,
          status: "delivered",
          date: "2023-03-15",
          paymentMethod: "M-Pesa",
        },
        {
          id: "#KE-2344",
          customer: "Jane Smith",
          email: "jane.smith@example.com",
          items: 2,
          total: 8750,
          status: "processing",
          date: "2023-03-14",
          paymentMethod: "Credit Card",
        },
        {
          id: "#KE-2343",
          customer: "Michael Johnson",
          email: "michael.j@example.com",
          items: 1,
          total: 5299,
          status: "shipped",
          date: "2023-03-13",
          paymentMethod: "M-Pesa",
        },
        {
          id: "#KE-2342",
          customer: "Sarah Williams",
          email: "sarah.w@example.com",
          items: 4,
          total: 3499,
          status: "delivered",
          date: "2023-03-12",
          paymentMethod: "PayPal",
        },
        {
          id: "#KE-2341",
          customer: "David Brown",
          email: "david.b@example.com",
          items: 2,
          total: 9999,
          status: "cancelled",
          date: "2023-03-11",
          paymentMethod: "Credit Card",
        },
        {
          id: "#KE-2340",
          customer: "Emily Davis",
          email: "emily.d@example.com",
          items: 1,
          total: 4599,
          status: "pending",
          date: "2023-03-10",
          paymentMethod: "M-Pesa",
        },
        {
          id: "#KE-2339",
          customer: "Robert Wilson",
          email: "robert.w@example.com",
          items: 3,
          total: 7899,
          status: "processing",
          date: "2023-03-09",
          paymentMethod: "Credit Card",
        },
        {
          id: "#KE-2338",
          customer: "Jennifer Lee",
          email: "jennifer.l@example.com",
          items: 2,
          total: 6299,
          status: "shipped",
          date: "2023-03-08",
          paymentMethod: "PayPal",
        },
        {
          id: "#KE-2337",
          customer: "Thomas Clark",
          email: "thomas.c@example.com",
          items: 5,
          total: 15999,
          status: "delivered",
          date: "2023-03-07",
          paymentMethod: "M-Pesa",
        },
        {
          id: "#KE-2336",
          customer: "Lisa Anderson",
          email: "lisa.a@example.com",
          items: 1,
          total: 2499,
          status: "delivered",
          date: "2023-03-06",
          paymentMethod: "Credit Card",
        },
      ])
    }, 1000)
  })
}

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [filteredOrders, setFilteredOrders] = useState<Order[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  useEffect(() => {
    const loadOrders = async () => {
      setIsLoading(true)
      try {
        const data = await fetchOrders()
        setOrders(data)
        setFilteredOrders(data)
      } catch (error) {
        console.error("Error loading orders:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadOrders()
  }, [])

  useEffect(() => {
    let filtered = orders

    // Apply status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter((order) => order.status === statusFilter)
    }

    // Apply search filter
    if (searchQuery.trim() !== "") {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (order) =>
          order.id.toLowerCase().includes(query) ||
          order.customer.toLowerCase().includes(query) ||
          order.email.toLowerCase().includes(query),
      )
    }

    setFilteredOrders(filtered)
  }, [searchQuery, statusFilter, orders])

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge className="bg-blue-500">Pending</Badge>
      case "processing":
        return <Badge className="bg-yellow-500">Processing</Badge>
      case "shipped":
        return <Badge className="bg-indigo-500">Shipped</Badge>
      case "delivered":
        return <Badge className="bg-green-500">Delivered</Badge>
      case "cancelled":
        return <Badge className="bg-red-500">Cancelled</Badge>
      default:
        return <Badge>Unknown</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Orders</h1>
          <p className="text-muted-foreground">Manage and track customer orders.</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <CardTitle>Order Management</CardTitle>
              <CardDescription>
                {isLoading ? "Loading orders..." : `Showing ${filteredOrders.length} of ${orders.length} orders`}
              </CardDescription>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search orders..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-40">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Orders</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="processing">Processing</SelectItem>
                  <SelectItem value="shipped">Shipped</SelectItem>
                  <SelectItem value="delivered">Delivered</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="h-96 flex items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order ID</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Items</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Payment</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredOrders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-medium">{order.id}</TableCell>
                    <TableCell>
                      <div>{order.customer}</div>
                      <div className="text-sm text-muted-foreground">{order.email}</div>
                    </TableCell>
                    <TableCell>{order.items}</TableCell>
                    <TableCell>Ksh {order.total.toLocaleString()}</TableCell>
                    <TableCell>{getStatusBadge(order.status)}</TableCell>
                    <TableCell>{new Date(order.date).toLocaleDateString()}</TableCell>
                    <TableCell>{order.paymentMethod}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Open menu</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="flex items-center gap-2">
                            <Eye className="h-4 w-4" /> View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem className="flex items-center gap-2">
                            <FileText className="h-4 w-4" /> Generate Invoice
                          </DropdownMenuItem>
                          {order.status !== "delivered" && order.status !== "cancelled" && (
                            <>
                              <DropdownMenuSeparator />
                              {order.status !== "shipped" && (
                                <DropdownMenuItem className="flex items-center gap-2">
                                  <Truck className="h-4 w-4" /> Mark as Shipped
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem className="flex items-center gap-2 text-red-500">
                                <XCircle className="h-4 w-4" /> Cancel Order
                              </DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

