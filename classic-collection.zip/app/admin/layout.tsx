import type React from "react"
import { AdminSidebar } from "@/components/admin-sidebar"
import { SidebarInset } from "@/components/ui/sidebar"

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex min-h-screen">
      <AdminSidebar />
      <SidebarInset>
        <div className="p-6">{children}</div>
      </SidebarInset>
    </div>
  )
}

