"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Package, ShoppingCart, Users, DollarSign, ArrowUpRight, ArrowDownRight, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Types for our data
interface DashboardMetrics {
  revenue: {
    value: number
    change: number
  }
  orders: {
    value: number
    change: number
  }
  products: {
    value: number
    change: number
  }
  customers: {
    value: number
    change: number
  }
}

interface Order {
  id: string
  customer: string
  status: "delivered" | "processing" | "shipped" | "cancelled"
  amount: number
  date: string
}

interface Product {
  name: string
  category: string
  sales: number
  revenue: number
  stock: number
}

// Mock data functions
const fetchDashboardMetrics = (): Promise<DashboardMetrics> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        revenue: {
          value: 458623,
          change: 12.5,
        },
        orders: {
          value: 243,
          change: 8.2,
        },
        products: {
          value: 1324,
          change: 24,
        },
        customers: {
          value: 573,
          change: -2.5,
        },
      })
    }, 1500)
  })
}

const fetchRecentOrders = (): Promise<Order[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        {
          id: "#KE-2345",
          customer: "John Doe",
          status: "delivered",
          amount: 12500,
          date: "2023-03-15",
        },
        {
          id: "#KE-2344",
          customer: "Jane Smith",
          status: "processing",
          amount: 8750,
          date: "2023-03-14",
        },
        {
          id: "#KE-2343",
          customer: "Michael Johnson",
          status: "shipped",
          amount: 5299,
          date: "2023-03-13",
        },
        {
          id: "#KE-2342",
          customer: "Sarah Williams",
          status: "delivered",
          amount: 3499,
          date: "2023-03-12",
        },
        {
          id: "#KE-2341",
          customer: "David Brown",
          status: "cancelled",
          amount: 9999,
          date: "2023-03-11",
        },
      ])
    }, 1000)
  })
}

const fetchTopProducts = (): Promise<Product[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        {
          name: "Wireless Headphones",
          category: "Electronics",
          sales: 124,
          revenue: 929876,
          stock: 45,
        },
        {
          name: "Women's Summer Dress",
          category: "Women's Fashion",
          sales: 98,
          revenue: 323302,
          stock: 12,
        },
        {
          name: "Leather Watch",
          category: "Watches",
          sales: 87,
          revenue: 521913,
          stock: 23,
        },
        {
          name: "Men's Casual Shirt",
          category: "Men's Fashion",
          sales: 76,
          revenue: 189924,
          stock: 34,
        },
        {
          name: "Coffee Table",
          category: "Home Furniture",
          sales: 52,
          revenue: 441948,
          stock: 8,
        },
      ])
    }, 1200)
  })
}

export default function AdminDashboard() {
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null)
  const [orders, setOrders] = useState<Order[] | null>(null)
  const [products, setProducts] = useState<Product[] | null>(null)
  const [timeframe, setTimeframe] = useState("month")
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("recent-orders")

  useEffect(() => {
    const loadDashboardData = async () => {
      setIsLoading(true)
      try {
        const [metricsData, ordersData, productsData] = await Promise.all([
          fetchDashboardMetrics(),
          fetchRecentOrders(),
          fetchTopProducts(),
        ])

        setMetrics(metricsData)
        setOrders(ordersData)
        setProducts(productsData)
      } catch (error) {
        console.error("Error loading dashboard data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadDashboardData()
  }, [])

  const handleRefresh = async () => {
    setIsLoading(true)
    try {
      const [metricsData, ordersData, productsData] = await Promise.all([
        fetchDashboardMetrics(),
        fetchRecentOrders(),
        fetchTopProducts(),
      ])

      setMetrics(metricsData)
      setOrders(ordersData)
      setProducts(productsData)
    } catch (error) {
      console.error("Error refreshing dashboard data:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleTimeframeChange = (value: string) => {
    setTimeframe(value)
    handleRefresh()
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100"
      case "processing":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100"
      case "shipped":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100"
      case "cancelled":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-100"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">Overview of your store's performance and recent activity.</p>
        </div>
        <div className="flex items-center gap-4">
          <Select value={timeframe} onValueChange={handleTimeframeChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select timeframe" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="day">Today</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="year">This Year</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={handleRefresh} disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Loading...
              </>
            ) : (
              "Refresh"
            )}
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading || !metrics ? (
              <div className="h-14 flex items-center justify-center">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <>
                <div className="text-2xl font-bold">Ksh {metrics.revenue.value.toLocaleString()}</div>
                <div
                  className={`flex items-center text-sm ${metrics.revenue.change >= 0 ? "text-green-500" : "text-red-500"}`}
                >
                  {metrics.revenue.change >= 0 ? (
                    <ArrowUpRight className="mr-1 h-4 w-4" />
                  ) : (
                    <ArrowDownRight className="mr-1 h-4 w-4" />
                  )}
                  <span>{`${Math.abs(metrics.revenue.change)}% from last ${timeframe}`}</span>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Orders</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading || !metrics ? (
              <div className="h-14 flex items-center justify-center">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <>
                <div className="text-2xl font-bold">+{metrics.orders.value}</div>
                <div
                  className={`flex items-center text-sm ${metrics.orders.change >= 0 ? "text-green-500" : "text-red-500"}`}
                >
                  {metrics.orders.change >= 0 ? (
                    <ArrowUpRight className="mr-1 h-4 w-4" />
                  ) : (
                    <ArrowDownRight className="mr-1 h-4 w-4" />
                  )}
                  <span>{`${Math.abs(metrics.orders.change)}% from last ${timeframe}`}</span>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Products</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading || !metrics ? (
              <div className="h-14 flex items-center justify-center">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <>
                <div className="text-2xl font-bold">{metrics.products.value}</div>
                <div className="flex items-center text-sm text-green-500">
                  <ArrowUpRight className="mr-1 h-4 w-4" />
                  <span>
                    +{metrics.products.change} new this {timeframe}
                  </span>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Customers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading || !metrics ? (
              <div className="h-14 flex items-center justify-center">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <>
                <div className="text-2xl font-bold">+{metrics.customers.value}</div>
                <div
                  className={`flex items-center text-sm ${metrics.customers.change >= 0 ? "text-green-500" : "text-red-500"}`}
                >
                  {metrics.customers.change >= 0 ? (
                    <ArrowUpRight className="mr-1 h-4 w-4" />
                  ) : (
                    <ArrowDownRight className="mr-1 h-4 w-4" />
                  )}
                  <span>{`${Math.abs(metrics.customers.change)}% from last ${timeframe}`}</span>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="recent-orders" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="recent-orders">Recent Orders</TabsTrigger>
          <TabsTrigger value="top-products">Top Products</TabsTrigger>
        </TabsList>
        <TabsContent value="recent-orders" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Orders</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading || !orders ? (
                <div className="h-48 flex items-center justify-center">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-5 text-sm text-muted-foreground">
                    <div>Order ID</div>
                    <div>Customer</div>
                    <div>Status</div>
                    <div>Date</div>
                    <div className="text-right">Amount</div>
                  </div>
                  {orders.map((order) => (
                    <div key={order.id} className="grid grid-cols-5 items-center">
                      <div className="font-medium">{order.id}</div>
                      <div>{order.customer}</div>
                      <div>
                        <span
                          className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${getStatusColor(order.status)}`}
                        >
                          {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                        </span>
                      </div>
                      <div>{new Date(order.date).toLocaleDateString()}</div>
                      <div className="text-right">Ksh {order.amount.toLocaleString()}</div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="top-products" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Top Selling Products</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading || !products ? (
                <div className="h-48 flex items-center justify-center">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-5 text-sm text-muted-foreground">
                    <div>Product</div>
                    <div>Category</div>
                    <div>Sales</div>
                    <div>Stock</div>
                    <div className="text-right">Revenue</div>
                  </div>
                  {products.map((product, index) => (
                    <div key={index} className="grid grid-cols-5 items-center">
                      <div className="font-medium">{product.name}</div>
                      <div>{product.category}</div>
                      <div>{product.sales} units</div>
                      <div className={product.stock < 10 ? "text-red-500 font-medium" : ""}>
                        {product.stock} in stock
                      </div>
                      <div className="text-right">Ksh {product.revenue.toLocaleString()}</div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

